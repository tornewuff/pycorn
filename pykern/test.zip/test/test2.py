import test1
print 'test2 imported'
