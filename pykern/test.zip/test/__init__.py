print 'test.py successfully imported'
